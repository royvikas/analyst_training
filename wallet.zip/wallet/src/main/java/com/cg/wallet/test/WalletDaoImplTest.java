package com.cg.wallet.test;

import org.junit.Ignore;
import org.junit.Test;

import com.cg.wallet.bean.Account;
import com.cg.wallet.bean.Customer;
import com.cg.wallet.dao.WalletDao;
import com.cg.wallet.dao.WalletDaoImpl;
import com.cg.wallet.exception.WalletException;
import com.cg.wallet.service.WalletService;
import com.cg.wallet.service.WalletServiceImpl;

import junit.framework.TestCase;

public class WalletDaoImplTest extends TestCase {

	WalletDao wd = new WalletDaoImpl();
	WalletService ws = new WalletServiceImpl();
	Account a = new Account();
	
	
	@Test
	public void testCreateAccount() {
		
		assertEquals(10, a.getAccDetailMap().size());
		try {
			String id = wd.createAccount(new Customer("Rakhi","Patna","24","8521078374"), new Account("savings","25000"));
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		assertEquals(11, a.getAccDetailMap().size());
	}

	
	@Test
	public void testShowBalance() {
		try {
			assertEquals("50000",wd.showBalance("SBI1531121607174"));
		} catch (WalletException e) {
			System.err.println(e.getMessage());
		}
	}

	@Test
	public void testDeposit() {
		try {
			String bal = new String(wd.deposit("SBI1531121607174", "15000"));
			assertEquals("65000.0",bal);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
	@Test
	public void testWithdraw() {
		try {
			String bal = new String(wd.withdraw("SBI1531121607187", "50000"));
			assertEquals("800000.0",bal);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	public void testFundTransfer() {
		try {
			String bal = new String(wd.fundTransfer("SBI1531121607199", "10000","SBI1531121607190"));
			assertEquals("35000.0",bal);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	public void testPrintTransaction() {
		try {
			assertEquals(0,wd.printTransaction("SBI1531121607185").size());
		} catch (WalletException e) {
			System.err.println(e.getMessage());
			}
	}

}
