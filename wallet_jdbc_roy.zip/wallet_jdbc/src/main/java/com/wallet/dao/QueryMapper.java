package com.wallet.dao;

public class QueryMapper {

	public static final String INSERT_CUSTOMER = "INSERT INTO CUSTOMER VALUES(?,?,?,?,?,?)";
	public static final String INSERT_ACCOUNT = "INSERT INTO ACCOUNT VALUES(?,?,?,?)";
	public static final String INSERT_TRANSACTION = "INSERT INTO TRANSACTION VALUES(?,?,?,?,?,?,?)";
	
	public static final String GET_BALANCE = "SELECT account_balance FROM ACCOUNT WHERE account_number=?";
	public static final String GET_CUSTOMER_ID = "SELECT customer_id FROM ACCOUNT WHERE account_number=?";
	
	public static final String UPDATE_BALANCE = "UPDATE ACCOUNT SET account_balance=? WHERE account_number=?";
	public static final String CHECK_ACCOUNT = "SELECT * FROM ACCOUNT WHERE account_number=?";
	public static final String CHECK_PASSWORD = "SELECT ACCOUNT.account_number,CUSTOMER.customer_password FROM ACCOUNT, CUSTOMER WHERE ACCOUNT.customer_id=CUSTOMER.customer_id AND CUSTOMER.customer_password=? AND ACCOUNT.account_number=?";
	
	public static final String GET_TRANSACTIONS="SELECT * FROM TRANSACTION WHERE sender_account_number=? OR receiver_account_number=?";
	
	
}
