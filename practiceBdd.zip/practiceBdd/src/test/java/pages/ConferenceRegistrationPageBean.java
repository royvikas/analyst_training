package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ConferenceRegistrationPageBean {

	WebDriver driver;
	
	@FindBy(name="txtFN")
	private WebElement firstName;
	
	@FindBy(name="txtLN")
	private WebElement lastName;
	
	@FindBy(name="Email")
	private WebElement emailId;
	
	@FindBy(name="Phone")
	private WebElement phoneNo;
	
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[5]/td[2]/select")
	private WebElement peopleAttending;
	
	@FindBy(name="Address")
	private WebElement buildingRoom;
	
	@FindBy(name="Address2")
	private WebElement area;
	
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[9]/td[2]/select")
	private WebElement city;
	
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[10]/td[2]/select")
	private WebElement state;
	
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[12]/td[2]/input")
	private WebElement memberStatus;
	
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[14]/td/a")
	private WebElement btn;
	
	public ConferenceRegistrationPageBean(WebDriver driver) {
		
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public void setEmailId(String emailId) {
		this.emailId.sendKeys(emailId);
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo.sendKeys(phoneNo);
	}

	public void setPeopleAttending(String p) {
		Select pa= new Select(peopleAttending);
		//pa.deselectByVisibleText(p);
		pa.selectByVisibleText(p);
	}

	public void setBuildingRoom(String buildingRoom) {
		this.buildingRoom.sendKeys(buildingRoom);
	}

	public void setArea(String area) {
		this.area.sendKeys(area);
	}

	public void setCity(String c) {
		Select sel= new Select(city);
		//sel.deselectByVisibleText(c);
		sel.selectByVisibleText(c);
	}

	public void setState(String s) {
		Select st= new Select(state);
		//st.deselectByVisibleText(s);
		st.selectByVisibleText(s);
	}

	public void setMemberStatus() {
		this.memberStatus.click();;
	}

	public void setBtn() {
		this.btn.click();
	}
	
	
	
}
