package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PaymentDetailPageBean {

	WebDriver driver;
	
	@FindBy(id="txtCardholderName")
	private WebElement cardholderName;
	
	@FindBy(id="txtDebit")
	private WebElement debitCardNumber;
	
	@FindBy(id="txtCvv")
	private WebElement cvvNumber;
	
	@FindBy(id="txtMonth")
	private WebElement expiryMonth;
	
	@FindBy(id="txtYear")
	private WebElement expiryYear;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"btnPayment\"]")
	private WebElement btn2;

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	
	public PaymentDetailPageBean(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void setCardholderName(String cardholderName) {
		this.cardholderName.sendKeys(cardholderName);
	}

	public void setDebitCardNumber(String debitCardNumber) {
		this.debitCardNumber.sendKeys(debitCardNumber);
	}

	public void setCvvNumber(String cvvNumber) {
		this.cvvNumber.sendKeys(cvvNumber);
	}

	public void setExpiryMonth(String expiryMonth) {
		this.expiryMonth.sendKeys(expiryMonth);
	}

	public void setExpiryYear(String expiryYear) {
		this.expiryYear.sendKeys(expiryYear);
	}

	public void setBtn2() {
		this.btn2.click();;
	}
	
	
	
	
	
}
