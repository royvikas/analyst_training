package registration;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.ConferenceRegistrationPageBean;
import pages.PaymentDetailPageBean;

public class StepDef {

	private WebDriver driver;
	private ConferenceRegistrationPageBean conRegBean;
	private PaymentDetailPageBean payBean;
	
	@cucumber.api.java.Before
	public void setUp()
	{
		System.setProperty
		("webdriver.chrome.driver", "D:\\FreshStart\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		conRegBean = new ConferenceRegistrationPageBean(driver);
		payBean = new PaymentDetailPageBean(driver);
	}
	
	@Given("^Registration form is open$")
	public void registration_form_is_open() throws Throwable {
	    driver.get("D:\\FreshStart\\practiceBdd\\src\\main\\webapp\\ConferenceRegistartion.html");
	}

	@When("^I blindly click on next$")
	public void i_blindly_click_on_next() throws Throwable {
	   	conRegBean.setBtn();
	}

	@Then("^Alert message for first name$")
	public void alert_message_for_first_name() throws Throwable {
	   assertEquals(driver.switchTo().alert().getText(),"Please fill the First Name");
	   Thread.sleep(2000);
	}

	@When("^If i fill first name then click next$")
	public void if_i_fill_first_name_then_click_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
	   conRegBean.setFirstName("Vikas");
	   conRegBean.setBtn();
	}

	@Then("^Alert message for last name$")
	public void alert_message_for_last_name() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the Last Name");
		   Thread.sleep(2000);
	}

	@When("^If i fill lastname then click next$")
	public void if_i_fill_lastname_then_click_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conRegBean.setFirstName("Vikas");
		conRegBean.setLastName("Roy");
		   conRegBean.setBtn();
	}

	@Then("^Alert message to enter the mail$")
	public void alert_message_to_enter_the_mail() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the Email");
		   Thread.sleep(2000);
	}

	@When("^If i enter the wrong email$")
	public void if_i_enter_the_wrong_email() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conRegBean.setFirstName("Vikas");
		conRegBean.setLastName("Roy");
		conRegBean.setEmailId("vikas.com");
		   conRegBean.setBtn();
	}

	@Then("^Alert message for enter the valid mail$")
	public void alert_message_for_enter_the_valid_mail() throws Throwable {
			assertEquals(driver.switchTo().alert().getText(),"Please enter valid Email Id.");
			   Thread.sleep(2000);
	}

	@When("^after entering mail I click on next$")
	public void after_entering_mail_I_click_on_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conRegBean.setFirstName("Vikas");
		conRegBean.setLastName("Roy");
		conRegBean.setEmailId("vikasroy@gmail.com");
		   conRegBean.setBtn();
	}

	@Then("^Alert message to enter the phoneno$")
	public void alert_message_to_enter_the_phoneno() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the Contact No.");
		   Thread.sleep(2000);
	}

	@When("^If i enter the wrong phoneno$")
	public void if_i_enter_the_wrong_phoneno() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conRegBean.setFirstName("Vikas");
		conRegBean.setLastName("Roy");
		conRegBean.setEmailId("vikasroy@gmail.com");
		conRegBean.setPhoneNo("4356");   
		conRegBean.setBtn();
	}

	@Then("^Alert message for enter the valid phoneno$")
	public void alert_message_for_enter_the_valid_phoneno() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please enter valid Contact no.");
		   Thread.sleep(2000);
	}

	@When("^after entering phoneno I click on next$")
	public void after_entering_phoneno_I_click_on_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conRegBean.setFirstName("Vikas");
		conRegBean.setLastName("Roy");
		conRegBean.setEmailId("vikasroy@gmail.com");
		conRegBean.setPhoneNo("9878355364");   
		conRegBean.setBtn();
	}

	@Then("^Alert message to fill the Number of people attending$")
	public void alert_message_to_fill_the_Number_of_people_attending() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the Number of people attending");
		   Thread.sleep(2000);
	}

	@When("^after entering people attend I click on next$")
	public void after_entering_people_attend_I_click_on_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conRegBean.setFirstName("Vikas");
		conRegBean.setLastName("Roy");
		conRegBean.setEmailId("vikasroy@gmail.com");
		conRegBean.setPhoneNo("9878355364");  
		conRegBean.setPeopleAttending("2");
		conRegBean.setBtn();
	}

	@Then("^Alert message to fill the Building & Room No$")
	public void alert_message_to_fill_the_Building_Room_No() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the Building & Room No");
		   Thread.sleep(2000);
	}

	@When("^after entering building and room I click on next$")
	public void after_entering_building_and_room_I_click_on_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conRegBean.setFirstName("Vikas");
		conRegBean.setLastName("Roy");
		conRegBean.setEmailId("vikasroy@gmail.com");
		conRegBean.setPhoneNo("9878355364");  
		conRegBean.setPeopleAttending("2");
		conRegBean.setBuildingRoom("Zolo 503");
		conRegBean.setBtn();
	}

	@Then("^Alert message to fill the Area name$")
	public void alert_message_to_fill_the_Area_name() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the Area name");
		   Thread.sleep(2000);
	}

	@When("^after entering area I click on next$")
	public void after_entering_area_I_click_on_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conRegBean.setFirstName("Vikas");
		conRegBean.setLastName("Roy");
		conRegBean.setEmailId("vikasroy@gmail.com");
		conRegBean.setPhoneNo("9878355364");  
		conRegBean.setPeopleAttending("2");
		conRegBean.setBuildingRoom("Zolo 503");
		conRegBean.setArea("Pristine Pavallion");
		conRegBean.setBtn();
	}

	@Then("^Alert message to fill the city$")
	public void alert_message_to_fill_the_city() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please select city");
		   Thread.sleep(2000);
	}

	@When("^after entering city I click on next$")
	public void after_entering_city_I_click_on_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conRegBean.setFirstName("Vikas");
		conRegBean.setLastName("Roy");
		conRegBean.setEmailId("vikasroy@gmail.com");
		conRegBean.setPhoneNo("9878355364");  
		conRegBean.setPeopleAttending("2");
		conRegBean.setBuildingRoom("Zolo 503");
		conRegBean.setArea("Pristine Pavallion");
		conRegBean.setCity("Chennai");
		conRegBean.setBtn();
	}

	@Then("^Alert message to fill the state$")
	public void alert_message_to_fill_the_state() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please select state");
		   Thread.sleep(2000);
	}

	@When("^after entering state I click on next$")
	public void after_entering_state_I_click_on_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conRegBean.setFirstName("Vikas");
		conRegBean.setLastName("Roy");
		conRegBean.setEmailId("vikasroy@gmail.com");
		conRegBean.setPhoneNo("9878355364");  
		conRegBean.setPeopleAttending("2");
		conRegBean.setBuildingRoom("Zolo 503");
		conRegBean.setArea("Pristine Pavallion");
		conRegBean.setCity("Chennai");
		conRegBean.setState("Tamilnadu");
		conRegBean.setBtn();
	}
	
	@Then("^Alert message to chose member$")
	public void alert_message_to_chose_member() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please Select MemeberShip status");
		   Thread.sleep(2000);
	}

	@When("^choosing  your membership and click on next$")
	public void choosing_your_membership_and_click_on_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conRegBean.setFirstName("Vikas");
		conRegBean.setLastName("Roy");
		conRegBean.setEmailId("vikasroy@gmail.com");
		conRegBean.setPhoneNo("9878355364");  
		conRegBean.setPeopleAttending("2");
		conRegBean.setBuildingRoom("Zolo 503");
		conRegBean.setArea("Pristine Pavallion");
		conRegBean.setCity("Chennai");
		conRegBean.setState("Tamilnadu");
		conRegBean.setMemberStatus();
		conRegBean.setBtn();
	}

	@Then("^Popup showing Personal details are validated$")
	public void popup_showing_Personal_details_are_validated() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Personal details are validated.");
		   Thread.sleep(5000);
		   
	}

	@Then("^you are redirected to payment page$")
	public void you_are_redirected_to_payment_page() throws Throwable {
		driver.switchTo().alert().accept();
	}

	
	
	@When("^next i blindly click on submit$")
	public void next_i_blindly_click_on_submit() throws Throwable {
		payBean.setBtn2();
	}

	@Then("^Alert message to fill the Card holder name$")
	public void alert_message_to_fill_the_Card_holder_name() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the Card holder name");
		   Thread.sleep(2000);
	}

	@When("^After i fill card holder name and click submit$")
	public void after_i_fill_card_holder_name_and_click_submit() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		payBean.setCardholderName("Vikas Roy");
		payBean.setBtn2();
	}

	@Then("^Alert message to fill the card number$")
	public void alert_message_to_fill_the_card_number() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the Debit card Number");
		   Thread.sleep(2000);
	}

	@When("^After i fill card number and click submit$")
	public void after_i_fill_card_number_and_click_submit() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		payBean.setCardholderName("Vikas Roy");
		payBean.setDebitCardNumber("564534234567");
		payBean.setBtn2();
	}

	@Then("^Alert message to fill the cvv number$")
	public void alert_message_to_fill_the_cvv_number() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the CVV");
		   Thread.sleep(2000);
	}

	@When("^After i fill cvv and click submit$")
	public void after_i_fill_cvv_and_click_submit() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		payBean.setCardholderName("Vikas Roy");
		payBean.setDebitCardNumber("564534234567");
		payBean.setCvvNumber("890");
		payBean.setBtn2();
	}

	@Then("^Alert message to fill the expiry month$")
	public void alert_message_to_fill_the_expiry_month() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill expiration month");
		   Thread.sleep(2000);
	}

	@When("^If i fill month and click submit$")
	public void if_i_fill_month_and_click_submit() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		payBean.setCardholderName("Vikas Roy");
		payBean.setDebitCardNumber("564534234567");
		payBean.setCvvNumber("890");
		payBean.setExpiryMonth("06");
		payBean.setBtn2();
	}

	@Then("^Alert message to fill the expiry year$")
	public void alert_message_to_fill_the_expiry_year() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the expiration year");
		   Thread.sleep(2000);
	}

	@When("^After i fill year and click submit$")
	public void after_i_fill_year_and_click_submit() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		payBean.setCardholderName("Vikas Roy");
		payBean.setDebitCardNumber("564534234567");
		payBean.setCvvNumber("890");
		payBean.setExpiryMonth("06");
		payBean.setExpiryYear("2025");
		payBean.setBtn2();
	}

	@Then("^Alert message for successful registration$")
	public void alert_message_for_successful_registration() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Conference Room Booking successfully done!!!");
		   Thread.sleep(5000);
	}


	@After
	public void shutDown() {
		driver.close();
	}
	
	
}
