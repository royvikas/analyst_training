package com.capgemini.pages;

import org.openqa.selenium.WebDriver;

public class SuccessPageBean {

	WebDriver driver;
	
	
}
