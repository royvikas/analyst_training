package com.capgemini.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPageBean {

	WebDriver driver;
	
	@FindBy(name="userName")
	private WebElement userName;
	
	@FindBy(name="userPwd")
	private WebElement passowrd;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")
	private WebElement btn;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"userErrMsg\"]")
	private WebElement userError;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"pwdErrMsg\"]")
	private WebElement userPwd;
	
	public LoginPageBean(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement getUserName() {
		return userName;
	}

	public WebElement getPassowrd() {
		return passowrd;
	}


	public WebElement getBtn() {
		return btn;
	}

	public void setBtn(WebElement btn) {
		this.btn = btn;
	}



	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}

	public void setPassowrd(String passowrd) {
		this.passowrd.sendKeys(passowrd);
	}

	public void setBtn() {
		this.btn.click();
	}

	public WebElement getUserError() {
		return userError;
	}

	public void setUserError(WebElement userError) {
		this.userError = userError;
	}

	public WebElement getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(WebElement userPwd) {
		this.userPwd = userPwd;
	}
	
	
	
}
