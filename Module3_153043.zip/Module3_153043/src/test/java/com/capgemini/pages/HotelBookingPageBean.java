package com.capgemini.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class HotelBookingPageBean {

	WebDriver driver;
	
	@FindBy(name="txtFN")
	private WebElement firstName;
	
	@FindBy(name="txtLN")
	private WebElement lastName;
	
	@FindBy(name="Email")
	private WebElement email;
	
	@FindBy(name="Phone")
	private WebElement phone;
	
	@FindBy(name="city")
	private WebElement city;
	
	@FindBy(name="state")
	private WebElement state;
	
	@FindBy(name="persons")
	private WebElement guestCount;
	
	@FindBy(id="txtCardholderName")
	private WebElement cardHolderName;
	
	@FindBy(name="debit")
	private WebElement debitCardNumber;
	
	@FindBy(name="cvv")
	private WebElement cvvNo;
	
	@FindBy(name="month")
	private WebElement expiryMonth;
	
	@FindBy(name="year")
	private WebElement expiryYear;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"btnPayment\"]")
	private WebElement confirm;
	
	public HotelBookingPageBean(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);
	}


	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public void setGuestCount(String guestCount) {
		this.guestCount.sendKeys(guestCount);
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);
	}

	public void setDebitCardNumber(String debitCardNumber) {
		this.debitCardNumber.sendKeys(debitCardNumber);
	}

	public void setCvvNo(String cvvNo) {
		this.cvvNo.sendKeys(cvvNo);
	}

	public void setExpiryMonth(String expiryMonth) {
		this.expiryMonth.sendKeys(expiryMonth);
	}

	public void setExpiryYear(String expiryYear) {
		this.expiryYear.sendKeys(expiryYear);
	}


	public WebElement getConfirm() {
		return confirm;
	}

	public void setConfirm() {
		this.confirm.click();
	}
	
}
