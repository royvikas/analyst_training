package hotelbooking;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.pages.HotelBookingPageBean;
import com.capgemini.pages.LoginPageBean;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {

	private WebDriver driver;
	private LoginPageBean loginpb;
	private HotelBookingPageBean hotelpb;
	
	@cucumber.api.java.Before
	public void setUp()
	{
		System.setProperty
		("webdriver.chrome.driver", "D:\\FreshStart\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		loginpb = new LoginPageBean(driver);
		hotelpb = new HotelBookingPageBean(driver);
	}
	
	@Given("^Details of everything is given$")
	public void details_of_everything_is_given() throws Throwable {
		driver.get("D:\\Module3\\Module3_153043\\src\\main\\webapp\\WEB-INF\\login.html");
	}

	@When("^I blindly click login button$")
	public void i_blindly_click_login_button() throws Throwable {
	    loginpb.setBtn();
	}

	@Then("^error to enter username$")
	public void error_to_enter_username() throws Throwable {
		assertEquals(loginpb.getUserError()," * Please enter userName.");
		   Thread.sleep(2000);
	}

	@When("^After entering username i click Login$")
	public void after_entering_username_i_click_Login() throws Throwable {
		driver.navigate().refresh();
		loginpb.setUserName("capgemini");
		loginpb.setPassowrd(null);
	    loginpb.setBtn();
	}

	@Then("^error to enter password$")
	public void error_to_enter_password() throws Throwable {
		assertEquals(loginpb.getUserPwd()," * Please enter password.");
		   Thread.sleep(2000);
	}

	@When("^I fill all details and press login$")
	public void i_fill_all_details_and_press_login() throws Throwable {
		driver.navigate().refresh();
		loginpb.setUserName("capgemini");
			loginpb.setPassowrd("cap123");
		    loginpb.setBtn();
	}

	@Then("^check for valid details$")
	public void check_for_valid_details() throws Throwable {
		assertEquals(loginpb.getUserName(),"gemini");
		assertEquals(loginpb.getPassowrd(),"cap123");
		assertEquals(driver.switchTo().alert().getText(),"Invalid login! Please try again!");
		   Thread.sleep(2000);
	}

	@When("^details matches with given credentials$")
	public void details_matches_with_given_credentials() throws Throwable {
		driver.navigate().refresh();
		driver.switchTo().alert().accept();
		loginpb.setUserName("capgemini");
		loginpb.setPassowrd("capg1234");
	    loginpb.setBtn();
	}

	@Then("^redirected to hotelbooking page$")
	public void redirected_to_hotelbooking_page() throws Throwable {
		driver.switchTo().alert().accept();
	}

	@When("^I directly click on confirm booking$")
	public void i_directly_click_on_confirm_booking() throws Throwable {
	    hotelpb.setConfirm();
	}

	@Then("^Alert to fill first name$")
	public void alert_to_fill_first_name() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the First Name");
		Thread.sleep(2000);
	}

	@When("^After filling first name and click confirm booking$")
	public void after_filling_first_name_and_click_confirm_booking() throws Throwable {
		driver.navigate().refresh();
		driver.switchTo().alert().accept();
		hotelpb.setFirstName("Ashwin");
		hotelpb.setConfirm();
	}

	@Then("^Alert to fill last name$")
	public void alert_to_fill_last_name() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the Last Name");
		Thread.sleep(2000);
	}

	@When("^After filling last name and click confirm booking$")
	public void after_filling_last_name_and_click_confirm_booking() throws Throwable {
		driver.navigate().refresh();
		driver.switchTo().alert().accept();
		hotelpb.setFirstName("Ashwin");
		hotelpb.setLastName("Gopal");
		hotelpb.setConfirm();
	}

	@Then("^Alert to fill email$")
	public void alert_to_fill_email() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the Email");
		Thread.sleep(2000);
	}

	@When("^I fill wrong email and click confirm booking$")
	public void i_fill_wrong_email_and_click_confirm_booking() throws Throwable {
		driver.navigate().refresh();
		driver.switchTo().alert().accept();
		hotelpb.setFirstName("Ashwin");
		hotelpb.setLastName("Gopal");
		hotelpb.setEmail("class.capg");
		hotelpb.setConfirm();
	}

	@Then("^Alert to fill valid email$")
	public void alert_to_fill_valid_email() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please enter valid Email Id.");
		Thread.sleep(2000);
	}

	@When("^After filling email and click confirm booking$")
	public void after_filling_email_and_click_confirm_booking() throws Throwable {
		driver.navigate().refresh();
		driver.switchTo().alert().accept();
		hotelpb.setFirstName("Ashwin");
		hotelpb.setLastName("Gopal");
		hotelpb.setEmail("ashwin_g@capg.com");
		hotelpb.setConfirm();
	}

	@Then("^Alert to fill phone number$")
	public void alert_to_fill_phone_number() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the Mobile No.");
		Thread.sleep(2000);
	}

	@When("^I fill wrong phone number and click confirm booking$")
	public void i_fill_wrong_phone_number_and_click_confirm_booking() throws Throwable {
		driver.navigate().refresh();
		driver.switchTo().alert().accept();
		hotelpb.setFirstName("Ashwin");
		hotelpb.setLastName("Gopal");
		hotelpb.setEmail("ashwin_g@capg.com");
		hotelpb.setPhone("45821");
		hotelpb.setConfirm();
	}

	@Then("^Alert to fill valid phone number$")
	public void alert_to_fill_valid_phone_number() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please enter valid Contact no.");
		Thread.sleep(2000);
	}

	@When("^After filling phone number and click confirm booking$")
	public void after_filling_phone_number_and_click_confirm_booking() throws Throwable {
		driver.navigate().refresh();
		driver.switchTo().alert().accept();
		hotelpb.setFirstName("Ashwin");
		hotelpb.setLastName("Gopal");
		hotelpb.setEmail("ashwin_g@capg.com");
		hotelpb.setPhone("9878451245");
		hotelpb.setConfirm();
	}

	@Then("^Alert to fill number of people attending$")
	public void alert_to_fill_number_of_people_attending() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the Number of people attending");
		Thread.sleep(2000);
	}

	@When("^After filling number of people attending and click confirm booking$")
	public void after_filling_number_of_people_attending_and_click_confirm_booking() throws Throwable {
		driver.navigate().refresh();
		driver.switchTo().alert().accept();
		hotelpb.setFirstName("Ashwin");
		hotelpb.setLastName("Gopal");
		hotelpb.setEmail("ashwin_g@capg.com");
		hotelpb.setPhone("9878451245");
		hotelpb.setGuestCount("5");
		hotelpb.setConfirm();
	}

	@Then("^Alert to select city$")
	public void alert_to_select_city() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please select city");
		Thread.sleep(2000);
	}

	@When("^After filling city and click confirm booking$")
	public void after_filling_city_and_click_confirm_booking() throws Throwable {
		driver.navigate().refresh();
		driver.switchTo().alert().accept();
		hotelpb.setFirstName("Ashwin");
		hotelpb.setLastName("Gopal");
		hotelpb.setEmail("ashwin_g@capg.com");
		hotelpb.setPhone("9878451245");
		hotelpb.setGuestCount("5");
		hotelpb.setCity("Chennai");
		hotelpb.setConfirm();
	}

	@Then("^Alert to select state$")
	public void alert_to_select_state() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please select state");
		Thread.sleep(2000);
	}

	@When("^After filling state and click confirm booking$")
	public void after_filling_state_and_click_confirm_booking() throws Throwable {
		driver.navigate().refresh();
		driver.switchTo().alert().accept();
		hotelpb.setFirstName("Ashwin");
		hotelpb.setLastName("Gopal");
		hotelpb.setEmail("ashwin_g@capg.com");
		hotelpb.setPhone("9878451245");
		hotelpb.setGuestCount("5");
		hotelpb.setCity("Chennai");
		hotelpb.setState("Tamilnadu");
		hotelpb.setConfirm();
	}

	@Then("^Alert to fill card holder name$")
	public void alert_to_fill_card_holder_name() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the Card holder name");
		Thread.sleep(2000);
	}

	@When("^After filling card holder name and click confirm booking$")
	public void after_filling_card_holder_name_and_click_confirm_booking() throws Throwable {
		driver.navigate().refresh();
		driver.switchTo().alert().accept();
		hotelpb.setFirstName("Ashwin");
		hotelpb.setLastName("Gopal");
		hotelpb.setEmail("ashwin_g@capg.com");
		hotelpb.setPhone("9878451245");
		hotelpb.setGuestCount("5");
		hotelpb.setCity("Chennai");
		hotelpb.setState("Tamilnadu");
		hotelpb.setCardHolderName("Akash Gopal");
		hotelpb.setConfirm();
	}

	@Then("^Alert to fill debit card number$")
	public void alert_to_fill_debit_card_number() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the Debit card Number");
		Thread.sleep(2000);
	}

	@When("^After filling debit card number and click confirm booking$")
	public void after_filling_debit_card_number_and_click_confirm_booking() throws Throwable {
		driver.navigate().refresh();
		driver.switchTo().alert().accept();
		hotelpb.setFirstName("Ashwin");
		hotelpb.setLastName("Gopal");
		hotelpb.setEmail("ashwin_g@capg.com");
		hotelpb.setPhone("9878451245");
		hotelpb.setGuestCount("5");
		hotelpb.setCity("Chennai");
		hotelpb.setState("Tamilnadu");
		hotelpb.setCardHolderName("Akash Gopal");
		hotelpb.setDebitCardNumber("4587125478986532");
		hotelpb.setConfirm();
	}

	@Then("^Alert to fill cvv number$")
	public void alert_to_fill_cvv_number() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the CVV");
		Thread.sleep(2000);
	}

	@When("^After filling cvv number and click confirm booking$")
	public void after_filling_cvv_number_and_click_confirm_booking() throws Throwable {
		driver.navigate().refresh();
		driver.switchTo().alert().accept();
		hotelpb.setFirstName("Ashwin");
		hotelpb.setLastName("Gopal");
		hotelpb.setEmail("ashwin_g@capg.com");
		hotelpb.setPhone("9878451245");
		hotelpb.setGuestCount("5");
		hotelpb.setCity("Chennai");
		hotelpb.setState("Tamilnadu");
		hotelpb.setCardHolderName("Akash Gopal");
		hotelpb.setDebitCardNumber("4587125478986532");
		hotelpb.setCvvNo("465");
		hotelpb.setConfirm();
	}

	@Then("^Alert to fill expiration month$")
	public void alert_to_fill_expiration_month() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill expiration month");
		Thread.sleep(2000);
	}

	@When("^After filling expiration month and click confirm booking$")
	public void after_filling_expiration_month_and_click_confirm_booking() throws Throwable {
		driver.navigate().refresh();
		driver.switchTo().alert().accept();
		hotelpb.setFirstName("Ashwin");
		hotelpb.setLastName("Gopal");
		hotelpb.setEmail("ashwin_g@capg.com");
		hotelpb.setPhone("9878451245");
		hotelpb.setGuestCount("5");
		hotelpb.setCity("Chennai");
		hotelpb.setState("Tamilnadu");
		hotelpb.setCardHolderName("Akash Gopal");
		hotelpb.setDebitCardNumber("4587125478986532");
		hotelpb.setCvvNo("465");
		hotelpb.setExpiryMonth("12");
		hotelpb.setConfirm();
	}

	@Then("^Alert to fill expiration year$")
	public void alert_to_fill_expiration_year() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the expiration year");
		Thread.sleep(2000);
	}

	@When("^After filling expiration year and click confirm booking$")
	public void after_filling_expiration_year_and_click_confirm_booking() throws Throwable {
		driver.navigate().refresh();
		driver.switchTo().alert().accept();
		hotelpb.setFirstName("Ashwin");
		hotelpb.setLastName("Gopal");
		hotelpb.setEmail("ashwin_g@capg.com");
		hotelpb.setPhone("9878451245");
		hotelpb.setGuestCount("5");
		hotelpb.setCity("Chennai");
		hotelpb.setState("Tamilnadu");
		hotelpb.setCardHolderName("Akash Gopal");
		hotelpb.setDebitCardNumber("4587125478986532");
		hotelpb.setCvvNo("465");
		hotelpb.setExpiryMonth("12");
		hotelpb.setExpiryYear("2021");
		hotelpb.setConfirm();
	}

	@Then("^Redirected to success page\\.$")
	public void redirected_to_success_page() throws Throwable {
		driver.switchTo().alert().accept();
	}

	
}
