package com.cg.wallet.bean;

public class AccountNumber {

	private static String acc_no;
	
	

	public  String getAccount_Number() {
		return acc_no;
	}

	public  void setAccount_Number(String account_number) {
		AccountNumber.acc_no = account_number;
	}

	public AccountNumber(String account_number) {
		super();
		this.acc_no = account_number;
	}

	public AccountNumber() {
		super();
		this.acc_no = "SBI"+ System.currentTimeMillis();
	}
	
	
}
